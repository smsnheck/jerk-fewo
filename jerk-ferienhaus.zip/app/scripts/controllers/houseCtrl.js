'use strict';
var houseModule = angular.module('jerk.fewo.house', []);

houseModule.controller('HouseCtrl', [function() {
}]);