'use strict';
var contactModule = angular.module('jerk.fewo.contact', []);
contactModule.controller('ContactCtrl', [function() {
	
}]);