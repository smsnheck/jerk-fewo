'use strict';
var impressModule = angular.module('jerk.fewo.impress', []);
impressModule.controller('ImpressCtrl', [function() {
	
}]);