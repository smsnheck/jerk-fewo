'use strict';

/**
 * @ngdoc function
 * @name jerkFewoApp.controller:MainCtrl
 * @description
 * # MainCtrl
 * Controller of the jerkFewoApp
 */
angular.module('jerkFewoApp')
  .controller('MainCtrl', function ($scope) {
  	$scope.heading = 'Main ctrl';
  });
